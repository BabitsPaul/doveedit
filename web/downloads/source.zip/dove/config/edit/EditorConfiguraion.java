package dove.config.edit;

import dove.config.Configuration;
import dove.util.struct.tree.StringTree;

public class EditorConfiguraion
    extends Configuration
{
    public static String getID() {
        return "configeditor";
    }

    @Override
    public StringTree<ConfigEditElem> getEditTree() {
        return null;
    }
}
