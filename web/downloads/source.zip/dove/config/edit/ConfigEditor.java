package dove.config.edit;

import dove.config.ConfigLoader;
import dove.config.Configuration;
import dove.document.DocumentContext;
import dove.util.struct.tree.StringTree;
import dove.util.struct.tree.Tree;
import dove.util.struct.tree.TreeBuildException;
import dove.util.ui.select.SearchComboBox;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import java.awt.*;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.util.ArrayList;
import java.util.Iterator;

public class ConfigEditor
    extends ComponentAdapter
{
    private JFrame frame;

    private Configuration config;

    private ConfigLoader cfgLoader;

    private DocumentContext doc;

    private StringTree<ConfigEditElem> struct;

    private JSplitPane display;

    public ConfigEditor(DocumentContext doc)
    {
        if(doc.configEdit != null)
            throw new IllegalStateException("an configeditor has already been instancised for this runtime");

        config = doc.config.getConfiguration("configeditor");

        this.doc = doc;

        cfgLoader = doc.config;

        config.put("bounds" , new Rectangle(10 , 10 , 100 , 100));

        frame = doc.resources.requestFrame("configeditor");

        frame.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
        frame.setBounds((Rectangle) config.get("bounds"));
        frame.setVisible(false);

        //create contentpanes
        createStruct();
        preProcess();

        createUI();
    }

    public void show()
    {
        frame.setVisible(true);
    }

    private void setDisplayedConfig(JPanel panel)
    {

    }

    @Override
    public void componentResized(ComponentEvent e) {
        super.componentResized(e);

        config.put("bounds", e.getComponent().getBounds());
    }

    //////////////////////////////////////////////////////////////////////////////////////
    // ui creation
    //
    // provides all methods needed to creat a userinterface from
    // the structural infos provided in struct
    //////////////////////////////////////////////////////////////////////////////////////
    private void createUI()
    {
        display = new JSplitPane(JSplitPane.VERTICAL_SPLIT);

        display.setLeftComponent(createTree());

        frame.setContentPane(display);
    }

    private JTree createTree()
    {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode();

        ArrayList<Iterator<Tree<ConfigEditElem>>> structIterStack = new ArrayList<>();
        ArrayList<MutableTreeNode> parentNodeStack = new ArrayList<>();

        parentNodeStack.add(root);
        structIterStack.add(struct.getChildren().iterator());

        while(!structIterStack.isEmpty())
        {
            if(structIterStack.get(0).hasNext())
            {
                StringTree<ConfigEditElem> nextNode = (StringTree) structIterStack.get(0).next();

                MutableTreeNode nextNodeImpl;

                if(nextNode.getContent() != null)
                {
                    nextNodeImpl = new DefaultMutableTreeNode(nextNode.getContent());
                    //TODO only structures without content (content == value to edit)
                    //--> insert into specified panel
                }
            }
            else
            {
                structIterStack.remove(0);
                parentNodeStack.remove(0);
            }
        }

        return new JTree(root);
    }

    private JPanel createSearchPanel()
    {
        JPanel searchPanel = new JPanel();

        //TODO
        new SearchComboBox(null);

        return new JPanel();
    }

    //////////////////////////////////////////////////////////////////////////////////
    // structure parsing
    //
    // this part provides all methods necassary to parse
    // the structure of the configurationeditor from
    // what every configuration provides
    //////////////////////////////////////////////////////////////////////////////////

    /**
     * merges the structures for the
     * editor provided by every single
     * configuration into one single structure
     * which is used as the structure of this
     * editor
     */
    private void createStruct()
    {
        struct = new StringTree<>();

        for(Configuration c : cfgLoader.cfgMap.values())
            try {
                struct.merge(c.getEditTree());
            }catch (TreeBuildException e)
            {
                doc.error.handleException("failed to create configurationeditor" , e);
            }
    }

    /**
     * preprocess this tee to make it usable for this
     * display
     *
     * in this process all configurationproperties that
     * are not editable by he user will be removed from
     * @see dove.config.edit.ConfigEditor#struct
     */
    private void preProcess()
    {
        ArrayList<Iterator<Tree<ConfigEditElem>>> iterStack = new ArrayList<>();

        iterStack.add(struct.getChildren().iterator());

        while(!iterStack.isEmpty())
        {
            if(!iterStack.get(0).hasNext())
                iterStack.remove(0);
            else
            {
                Tree<ConfigEditElem> configEditElemTree = iterStack.get(0).next();

                if(configEditElemTree.getContent() != null)
                    if(cfgLoader.getConfiguration(configEditElemTree.getContent().configName).
                        userEditable(configEditElemTree.getContent().propertyName))
                            configEditElemTree.getParent().removeSubtree(configEditElemTree);

                if(configEditElemTree.getParent() != null &&
                        !configEditElemTree.getChildren().isEmpty())
                    iterStack.add(0 , configEditElemTree.getChildren().iterator());
            }
        }
    }
}