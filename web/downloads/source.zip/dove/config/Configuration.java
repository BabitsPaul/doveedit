package dove.config;

import dove.config.edit.ConfigEditElem;
import dove.util.StringHelper;
import dove.util.struct.MultiMap;
import dove.util.struct.stringmap.StringMap;
import dove.util.struct.tree.StringTree;
import sun.reflect.generics.reflectiveObjects.NotImplementedException;

import java.util.ArrayList;
import java.util.HashMap;

public abstract class Configuration
    extends StringMap<Object>
{
    static HashMap<String , Configuration> availableTypes;

    static{
        if(availableTypes == null)
            availableTypes = new HashMap<>();

        //register this subtype
        //TODO
        availableTypes.put(getID() , null);
    }

    {
        //if this configuration hasn't yet been
        //registered, it will be registered now
        //id must be unique
        if(!availableTypes.containsKey(getID())) {
            availableTypes.put(getID(), this);

            ConfigLoader.loadDefaultConfiguration(this);
        }
    }

    private MultiMap<String , ConfigListener> listeners = new MultiMap<>();

    private ArrayList<ConfigListener> notifyAlways = new ArrayList<>();

    private HashMap<String , Boolean> userAccess = new HashMap<>();

    protected void fireConfigChanged(String key)
    {
        listeners.get(key).forEach(l -> l.valueChanged(new ConfigChangedEvent(this, key)));

        notifyAlways.forEach(l -> l.valueChanged(new ConfigChangedEvent(this , key)));
    }

    public void addConfigChangedListener(ConfigListener cl , String key)
    {
        if(key == null)
            notifyAlways.add(cl);
        else
            if(!notifyAlways.contains(cl))
                listeners.add(key , cl);
    }

    public void put(String key , Object val) {
        if(!userAccess.get(key))
            throw new IllegalStateException("Configproperty " + key + " is not accessible");

        super.put(key , val);

        fireConfigChanged(key);
    }

    public void remove(String key)
    {
        super.remove(key);

        fireConfigChanged(key);
    }

    public Object get(String key)
    {
        return ((StringMap) getNodeForPath(StringHelper.castToChar(key.toCharArray()))).getVal();
    }

    public boolean userEditable(String key)
    {
        return userAccess.get(key);
    }

    @Deprecated
    public void removeVal(Object val){
        super.removeVal(val);
        //should not be used
        //since this method doesn't affect the listeners
    }

    public static String getID()
    {
        //this method must always be overriden
        //since it is used to register this class
        //as a configurationclass
        throw new NotImplementedException();
    }

    public abstract StringTree<ConfigEditElem> getEditTree();
}
