package dove.config;

public interface ConfigListener {
    public void valueChanged(ConfigChangedEvent e);
}
