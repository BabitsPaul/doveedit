package dove.lang;

import dove.document.DocumentContext;

public class LangProvider {
    public LangProvider(DocumentContext doc)
    {

    }
}
