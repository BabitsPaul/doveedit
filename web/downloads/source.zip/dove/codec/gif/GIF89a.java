package dove.codec.gif;

public class GIF89a {

}
