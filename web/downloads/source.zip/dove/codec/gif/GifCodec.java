package dove.codec.gif;

import dove.codec.InvalidFormatException;

import javax.management.Descriptor;
import java.awt.*;

public class GifCodec {
    //TODO configuration

}