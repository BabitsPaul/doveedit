package dove.codec;

public interface Element {
}
