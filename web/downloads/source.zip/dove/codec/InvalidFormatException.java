package dove.codec;

public class InvalidFormatException
    extends Exception
{
    public InvalidFormatException(String msg)
    {
        super(msg);
    }
}
