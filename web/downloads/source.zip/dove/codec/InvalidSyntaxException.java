package dove.codec;

/**
 * Created by Babits on 21/12/2014.
 */
public class InvalidSyntaxException
    extends Exception
{
    public InvalidSyntaxException(String msg)
    {
        super(msg);
    }
}
