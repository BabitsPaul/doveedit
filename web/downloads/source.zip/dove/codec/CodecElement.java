package dove.codec;

public interface CodecElement {
    public CodecComponent getCodecComponent(String format);
}