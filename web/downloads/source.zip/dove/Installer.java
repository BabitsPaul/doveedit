package dove;

import dove.error.ErrorHandler;

import java.io.*;
import java.util.HashMap;

public class Installer {
    private static HashMap<String , File> fileMap = new HashMap<>();

    static {
        fileMap.put("dove/config", new File(System.getProperty("user.home") + "/dove_edit/setup.cfg"));
    }

    public static void checkInstallation()
    {
        if(!isInstalled())
            install();
    }

    private static void install()
    {
        //setup files
        for(String key : fileMap.keySet())
        {
            try{
                boolean success = fileMap.get(key).getParentFile().mkdirs();
                success &= fileMap.get(key).createNewFile();

                if(!success)
                    throw new IOException("file key: " + key + " - unknown error");
            }catch (IOException e)
            {
                new ErrorHandler(null).handleException("failed to create file" , e);
            }
        }
    }

    public static void uninstall()
    {
        //remove files
        for(String key : fileMap.keySet())
        {
            boolean success = fileMap.get("dove/config").delete();
            if(!success)
                new ErrorHandler(null).handleException("failed to delete file" ,
                        new IOException("file key: " + key + " - unknown error"));
        }
    }

    private static boolean isInstalled()
    {
        Object val = GlobalFlags.getProperty("installed");

        boolean valid = val.equals("todo") || val.equals("done");

        if(!valid) {
            new ErrorHandler(null).handleException("Invalid argument",
                    new Exception("Launcher flag installed may only be either done or todo"));
        }


        return (GlobalFlags.getProperty("installed").equals("done"));
    }

    /////////////////////////////////////////////////////////////////////
    // JNI support
    //
    // OS link to do specific setup (registry, etc.)
    /////////////////////////////////////////////////////////////////////
    private static OSHelper osHelperSetup()
    {
        String os = System.getProperty("os.name");

        if(os.contains("windows"))
            return new WinOSHelper();
        else if(os.contains("mac"))
            return new MacOSHelper();
        else if(os.contains("linux"))
            return new LinuxOSHelper();
        else
            return null;//TODO no supported os --> throw exception
    }

    private static abstract class OSHelper
    {
        public abstract void reg_setup();
        public abstract void reg_remove();
    }

    private static class WinOSHelper
        extends OSHelper
    {
        @Override
        public native void reg_setup();

        @Override
        public native void reg_remove();
    }

    private static class LinuxOSHelper
        extends OSHelper
    {
        @Override
        public native void reg_setup();

        @Override
        public native void reg_remove();
    }

    private static class MacOSHelper
        extends OSHelper
    {
        @Override
        public native void reg_setup();

        @Override
        public native void reg_remove();
    }
}
