package dove;

import dove.config.edit.ConfigEditor;
import dove.config.ConfigLoader;
import dove.document.DocumentContext;
import dove.document.IDGiver;
import dove.error.ErrorHandler;
import dove.event.EventListener;
import dove.frame.Frame;
import dove.frame.menubar.MenuBar;
import dove.frame.menubar.MenubarTodo;
import dove.undo.UndoUtil;
import dove.util.struct.tree.StringTree;

public class Setup {
    public static DocumentContext setup()
    {
        DocumentContext context = new DocumentContext();

        context.error = new ErrorHandler(context);
        context.resources = new Resources(context);

        context.config = new ConfigLoader();
        context.config.load(context);

        context.idGiver = new IDGiver(context);
        context.menuTodo = new MenubarTodo(context);
        context.undo = new UndoUtil(context);

        context.frame = new Frame(context);
        context.menu = new MenuBar(context , new StringTree<>());
        context.event = new EventListener(context);
        context.configEdit = new ConfigEditor(context);

        context.menuTodo.apply();

        return context;
    }

    public static void tearDown(DocumentContext context)
    {
        context.config.save(context);

        context.resources.closeAll("shutdown");
    }
}