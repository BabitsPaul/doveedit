package dove.annotations;

import java.lang.annotation.*;

/**
 * marks a method as relevant for the setup
 */

@Target(ElementType.METHOD)
@Documented
@Retention(RetentionPolicy.SOURCE)
public @interface Setup {}
