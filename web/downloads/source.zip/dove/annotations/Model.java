package dove.annotations;

import java.lang.annotation.*;

/**
 * marks a method as modelrelevant
 */

@Documented
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.SOURCE)
public @interface Model {
}
