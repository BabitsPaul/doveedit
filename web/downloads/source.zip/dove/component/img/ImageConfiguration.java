package dove.component.img;

import dove.config.Configuration;
import dove.config.edit.ConfigEditElem;
import dove.util.struct.tree.StringTree;

public class ImageConfiguration
    extends Configuration
{
    public static String getID() {
        return "img";
    }

    @Override
    public StringTree<ConfigEditElem> getEditTree() {
        return null;
    }
}
