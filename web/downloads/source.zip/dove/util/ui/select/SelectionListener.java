package dove.util.ui.select;

public interface SelectionListener<T> {
    public void selected(SelectionEvent<T> e);
}
