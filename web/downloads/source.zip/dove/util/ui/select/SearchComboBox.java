package dove.util.ui.select;

import dove.annotations.Setup;
import dove.clipboard.InternalClipboardHelper;
import dove.util.miscellaneous.ColorUtil;
import dove.util.struct.tree.*;
import dove.util.struct.tree.TreeMap;
import dove.util.ui.Dialogs;

import javax.swing.*;
import javax.swing.plaf.basic.BasicArrowButton;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.util.*;
import java.util.List;

import static java.awt.event.KeyEvent.*;

public class SearchComboBox<T>
    extends JPanel
    implements KeyListener ,
        ActionListener ,
        MouseListener ,
        ComponentListener ,
        FocusListener
{
    private static final int XPOS_LEFT_BOUND = 5;

    public SearchComboBox(TreeMap<Character, T> provider)
    {
        //create basic vars
        possibleSelections = provider;
        provider.addModelChangedListener(e -> updateDisplayedOptions());

        currentSearch = "";

        currentOptionIndex = 0;

        fontUpdate = new ArrayList<>();

        cursorPosition = 0;

        selectionStart = 0;

        selectionEnd = 0;

        listeners = new ArrayList<>();

        popupVisible = false;

        fontMetrics = getFontMetrics(getFont());

        //setup component
        sizeHelper();

        setupUI();
    }

    //////////////////////////////////////////////////////////////////////
    // size
    //
    // provides size methods like set size,
    // update size, minimumSize, preferredSize, etc.
    //////////////////////////////////////////////////////////////////////

    /**
     * creates the minimumSize
     * and preferredSize Dimension for this element
     */
    @Setup
    private void sizeHelper()
    {
        int width = getFont().getSize() * 10;
        int height;

        if(fontMetrics == null) {
            height = getFont().getSize();

            //try to update the font
            try{
                fontMetrics = getFontMetrics(getFont());
            }catch (NullPointerException e){
                handleException(e , "couldn't create fontmetrics instance" ,
                        InternalExceptionCause.FONTMETRICS_NOT_AVAILABLE);
            }
        }
        else
            height = fontMetrics.getHeight();

        setMinimumSize(new Dimension(width , height + 2));

        setPreferredSize(new Dimension(width * 2 , height + 10));
    }

    //////////////////////////////////////////////////////////////////////
    // ui block
    //
    // provides methods to setup and handle the ui
    // related to this class
    //////////////////////////////////////////////////////////////////////

    private static final int CURSOR_RIGHT_SPACE = 5;

    private int scrollTextLeft = 0;

    private FontMetrics fontMetrics;

    private boolean popupVisible;

    private JPopupMenu popup;

    private JButton popupButton;

    private ArrayList<Component> fontUpdate;

    private Color selectedColor = Color.blue.brighter();

    private String infoString = "";

    private boolean displayInfoString = true;

    @Setup
    private void setupUI()
    {
        setLayout(new BorderLayout());

        addKeyListener(this);
        addMouseListener(this);
        setFocusable(true);

        popupButton = new BasicArrowButton(SwingConstants.SOUTH);
        popupButton.addActionListener(this);
        add(popupButton, BorderLayout.EAST);
        fontUpdate.add(popupButton);

        popup = new JPopupMenu("options");
        popup.setInvoker(this);
        popup.setFocusable(false);
        popupUpdateHelper();
        fontUpdate.add(popup);
    }

    private void setPopupVisible(boolean popupVisible)
    {
        if(popupVisible)
        {
            popup.setVisible(false);
        }else
        {
            popup.show(this , 0 , getHeight());
        }

        this.popupVisible = popupVisible;
    }

    private Thread currentUpdater;

    private void recreatePopup()
    {
        //if a previous updater is still running, interrupt it
        if(currentUpdater != null)
        {
            currentUpdater.interrupt();

            currentUpdater = null;
        }

        //start new updater thread and remove it as previous updater when done
        currentUpdater = new Thread(() -> SwingUtilities.invokeLater(() -> {
            popup.invalidate();

            popup.removeAll();

            JMenuItem load = new JMenuItem("load");
            popup.add(load);

            popupUpdateHelper();

            popup.remove(load);

            currentUpdater = null;

            if(currentOptions.isEmpty())
                popup.add(new JMenuItem("no results"));

            popup.validate();
            popup.repaint();

            //TODO create content properly
            //TODO apply content to size
        }));

        currentUpdater.setName("search result updater");
        currentUpdater.setDaemon(true);
        currentUpdater.start();
    }

    private void popupUpdateHelper()
    {
        //recalculate found options for this search
        updateDisplayedOptions();

        popup.invalidate();

        popup.removeAll();

        Iterator<String> optIter = currentOptions.iterator();

        int count = 1;
        while(optIter.hasNext()) {
            if ((count % 10) == 0) {
                JMenu more = new JMenu("more");
                popup.add(more);
            } else {
                String opt = optIter.next();

                JMenuItem jmi = new JMenuItem(opt);
                jmi.setActionCommand(opt);
                jmi.addActionListener(this);
                popup.add(jmi);
            }
        }

        popup.validate();
        popup.repaint();
    }

    private void updateText()
    {
        SwingUtilities.invokeLater(this::repaint);
    }

    @Override
    public void paintComponent(Graphics g)
    {
        //TODO paint mark at correct position
        super.paintComponent(g);
        super.paintComponents(g);

        int yPos_lower_bound = 5 + fontMetrics.getHeight();
        int cursorPosX =
                fontMetrics.stringWidth(currentSearch.substring(0 , cursorPosition))
                + XPOS_LEFT_BOUND + scrollTextLeft;

        g.setColor(getBackground());
        g.fillRect(1 , 1 , getWidth() - 2 , getHeight() - 2);

        if(displayInfoString)
        {
            g.drawString(infoString , XPOS_LEFT_BOUND , yPos_lower_bound);
        }
        else
        {
            if(selectionStart != selectionEnd)
            {
                g.setColor(selectedColor);

                int startX = calculateScreenPosition(selectionStart) + scrollTextLeft;
                int endX = calculateScreenPosition(selectionEnd) + scrollTextLeft;

                g.fillRect(startX , yPos_lower_bound - fontMetrics.getHeight() ,
                        endX , yPos_lower_bound);
            }

            g.setColor(getForeground());

            g.drawString(currentSearch , XPOS_LEFT_BOUND + scrollTextLeft , yPos_lower_bound);

            g.drawLine(cursorPosX , yPos_lower_bound - fontMetrics.getHeight() ,
                    cursorPosX , yPos_lower_bound);
        }

        g.drawRect(0 , 0 , getWidth() - popupButton.getWidth() - 1 , getHeight() - 1);
    }

    @Override
    public void setFont(Font f)
    {
        super.setFont(f);

        //used during initialization of superclass (method call without variable-initialisation)
        if(fontUpdate != null)
            fontUpdate.forEach(c -> c.setFont(f));

        fontMetrics = getFontMetrics(f);
    }

    @Override
    public void setForeground(Color foreground)
    {
        super.setForeground(foreground);

        selectedColor = ColorUtil.avgComplementaryColor(getForeground() , getBackground());
    }

    @Override
    public void setBackground(Color background)
    {
        super.setBackground(background);

        selectedColor = ColorUtil.avgComplementaryColor(getForeground() , getBackground());
    }

    public void setInfoString(String info)
    {
        infoString = info;
    }

    public void setDisplayedText(String text)
    {
        currentSearch = text;

        updateText();
    }

    private void calcScrollLeft()
    {
        int cursorPosX =
                fontMetrics.stringWidth(currentSearch.substring(0 , cursorPosition))
                        + XPOS_LEFT_BOUND;

        int visibleTextBoundRight = getWidth() - popupButton.getWidth() - CURSOR_RIGHT_SPACE;

        //the cursor is still within the visible part of the text
        //leave value
        if(cursorPosX + scrollTextLeft < visibleTextBoundRight)
            if(cursorPosX + scrollTextLeft < 0)
                scrollTextLeft = 0;
            else
                return;

        if(cursorPosX > visibleTextBoundRight)
            //calculate how much the text must be moved to the left to
            //make the full text visible
            scrollTextLeft = -(cursorPosX - visibleTextBoundRight) - CURSOR_RIGHT_SPACE;
    }

    private int calculateCharPosition(int mouseAtX)
    {
        int char_at = 0;

        //text starts after this position
        mouseAtX -= XPOS_LEFT_BOUND;

        //if the text is bigger than the component
        //the text will be moved -scrollTextLeft pixels to the left
        mouseAtX -= scrollTextLeft;

        //calculate new cursorposition
        while(mouseAtX > 0 && char_at < currentSearch.length())
            mouseAtX -= fontMetrics.charWidth(currentSearch.charAt(char_at++));


        return char_at - 1;
    }

    private int calculateScreenPosition(int atChar)
    {
        String toChar = currentSearch.substring(0 , atChar + 1);

        return fontMetrics.stringWidth(toChar);
    }

    /////////////////////////////////////////////////////////////////////////////
    // model
    /////////////////////////////////////////////////////////////////////////////

    private int cursorPosition;

    private int selectionStart;

    private int selectionEnd;

    private TreeMap<Character , T> possibleSelections;

    private String currentSearch;

    private AbstractList<String> currentOptions;

    private int currentOptionIndex;

    private boolean optionSelected = false;

    private void moveCursor(int deltaPos)
    {
        setCursor(cursorPosition + deltaPos);

        if(deltaPos > 0 && optionSelected)
            currentSearch = currentOptions.get(currentOptionIndex);

        updateText();
    }

    void openSelected()
    {
        //find selected element
        fireNotification(currentSearch);
    }

    void nextOption()
    {
        ++currentOptionIndex;

        optionSelected = true;

        //TODO mark on popup
    }

    void previousOption()
    {
        --currentOptionIndex;

        optionSelected = false;

        //TODO mark on popup
    }

    void removeChar()
    {
        if(currentSearch.length() == 0 || cursorPosition == 0)
            return;

        String partA;
        String partB;

        if(cursorPosition == currentSearch.length())
        {
            partA = currentSearch.substring(0 , currentSearch.length() - 1);
            partB = "";
        }else
        {
            partA = currentSearch.substring(0 , cursorPosition);
            partB = currentSearch.substring(cursorPosition + 1);
        }

        currentSearch = partA + partB;

        setCursor(cursorPosition - 1);

        recreatePopup();

        updateText();
    }

    void addChar(char c)
    {
        StringBuilder ins = new StringBuilder(currentSearch);

        ins.insert(cursorPosition, c);

        setText(ins.toString());

        setCursor(cursorPosition + 1);
    }

    private void setText(String text)
    {
        currentSearch = text;

        if(cursorPosition > text.length())
            setCursor(text.length());

        recreatePopup();

        updateText();
    }

    void selectText(int from , int to)
    {
        selectionStart = from;
        selectionEnd = to;

        updateText();
    }

    void setCursor(int at)
    {
        if(at < 0 || at > currentSearch.length())
            return;

        calcScrollLeft();

        cursorPosition = at;

        updateText();
    }

    void removeSelected()
    {
        String textA;
        String textB;

        if(selectionStart > 0)
            textA = currentSearch.substring(0 , selectionStart);
        else
            textA = "";

        if(selectionEnd < currentSearch.length() - 1)
            textB = currentSearch.substring(selectionEnd + 1);
        else
            textB = "";

        setText(textA + textB);
    }

    void copySelected()
    {
        //nothing selected
        if(selectionStart == selectionEnd)
            return;


        String selected = currentSearch.substring(selectionStart , selectionEnd);

        InternalClipboardHelper.setClipboardContent(selected);

        selectionStart = selectionEnd;
    }

    void pasteClipboard()
    {
        String currentString = InternalClipboardHelper.getClipboardContent();

        String nText;

        if(cursorPosition == 0)
            nText = currentString + currentSearch;
        else
            nText = currentString.substring(0 , cursorPosition) +
                    currentString +
                    currentString.substring(cursorPosition);

        setText(nText);
    }

    void cutSelected()
    {
        if(selectionStart == selectionEnd)
            return;

        InternalClipboardHelper.setClipboardContent(
                currentSearch.substring(selectionStart, selectionEnd));

        String textA;
        String textB;

        if(selectionStart == 0)
            textA = "";
        else
            textA = currentSearch.substring(0 , selectionStart);

        if(selectionEnd == currentSearch.length())
            textB = "";
        else
            textB = currentSearch.substring(selectionEnd);

        setText(textA + textB);
    }

    @SuppressWarnings("unchecked")
    void updateDisplayedOptions()
    {
        Character[] path = new Character[currentSearch.length()];
        for(int i = 0 ; i < path.length ; i++)
            path[i] = currentSearch.charAt(i);

        Collection<Tree<Character>> search;
        if(path.length == 0)
        {
            search = new ArrayList<>(1);
            search.add(possibleSelections);
        }else
            search = possibleSelections.listMatchingPaths(path);

        currentOptions = new ArrayList<>();

        for(Tree<Character> t : search)
        {
            Tree<Character> helper = new TreeMap<>();
            try {
                helper.add(t);
            } catch (TreeBuildException e) {
                handleException(e, "internal search error - invalid treestructure",
                        SearchComboBox.InternalExceptionCause.INVALID_DATA_STRUCTURE);
            }
            Tree<Character> pathEnd = helper.getNodeForPath(path);

            //generate current stringstub (start of all subpaths)
            String rootToPathEnd = "";
            boolean rootReached = false;
            Tree<Character> node = pathEnd;
            while(!rootReached)
            {
                if(node.contentSet())
                {
                    rootToPathEnd = node.getContent() + rootToPathEnd;
                }

                rootReached = (node.getParent() == null);
                if(!rootReached)
                    node = node.getParent();
            }

            //list all keystubs matching this subtree
            List<Character[]> keys = pathEnd.listPaths();

            for(Character[] optStub : keys) {
                String optStubStr = "";
                for(Character c : optStub)
                    optStubStr += c;

                currentOptions.add(rootToPathEnd + optStubStr);
            }
        }
    }

    /////////////////////////////////////////////////////////////////////////////
    // event handling
    //
    // processes events and translates them into actions
    /////////////////////////////////////////////////////////////////////////////

    private int startDragMouseX = 0;
    private int endDragMouseX = 0;

    private int textDragPos = 0;

    @Override
    public void keyTyped(KeyEvent e) {
        if(!searchComboBoxAvailable)
            return;

        if(e.isControlDown())
            switch (e.getKeyChar()) {
                case 'a':
                    selectText(0, currentSearch.length());
                    break;

                case 'c':
                    copySelected();
                    break;

                case 'v':
                    pasteClipboard();
                    break;

                case 'x':
                    cutSelected();
                    break;
            }

        if(     //filter backspace and enter
                e.getKeyChar() != '\n' &&
                e.getKeyChar() != '\b' &&
                e.getKeyChar() != '\r')
        {
            addChar(e.getKeyChar());
        }
    }

    @Override
    public void keyPressed(KeyEvent e) {
        if(!searchComboBoxAvailable)
            return;

        switch (e.getKeyCode())
        {
            case VK_RIGHT:
                moveCursor(1);
                break;

            case VK_LEFT:
                moveCursor(-1);
                break;

            case VK_DOWN:
                nextOption();
                break;

            case VK_UP:
                previousOption();
                break;

            case VK_ENTER:
                openSelected();
                break;

            case VK_BACK_SPACE:
                if(selectionStart == selectionEnd)
                    removeChar();
                else
                    removeSelected();
                break;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {}

    @Override
    public void actionPerformed(ActionEvent e)
    {
        if(!searchComboBoxAvailable)
            return;

        if(e.getSource().equals(popupButton))
            setPopupVisible(!popupVisible);
        else
        {
            fireNotification(e.getActionCommand());
        }
    }

    @Override
    public void mouseClicked(MouseEvent e) {
        //set new cursorposition
        setCursor(calculateCharPosition(e.getX()));
    }

    @Override
    public void mousePressed(MouseEvent e) {
        startDragMouseX = e.getX();
        endDragMouseX = e.getX();

        if(displayInfoString)
            displayInfoString = false;
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        endDragMouseX = e.getX();

        if(endDragMouseX != startDragMouseX)
        {
            selectionStart = calculateCharPosition(startDragMouseX);
            selectionEnd = calculateCharPosition(endDragMouseX);
        }
    }

    @Override
    public void mouseEntered(MouseEvent e) {
        //empty stub
    }

    @Override
    public void mouseExited(MouseEvent e) {
        //empty stub
    }

    @Override
    public void componentResized(ComponentEvent e) {
        //TODO update uivars
    }

    @Override
    public void componentMoved(ComponentEvent e) {
        if(popupVisible)
        {
            setPopupVisible(false);
            setPopupVisible(true);
        }
    }

    @Override
    public void componentShown(ComponentEvent e) {
        //empty stub
    }

    @Override
    public void componentHidden(ComponentEvent e) {
        setPopupVisible(false);
    }

    @Override
    public void focusGained(FocusEvent e) {
        //empty stub
    }

    @Override
    public void focusLost(FocusEvent e) {

        setPopupVisible(false);

        if(currentSearch.length() == 0)
            displayInfoString = true;
    }

    //////////////////////////////////////////////////////////////////////////////////
    // notification
    //
    // methods to notify listeners if an element has been selected
    //////////////////////////////////////////////////////////////////////////////////

    private ArrayList<SelectionListener<T>> listeners;

    public void addSelectionListener(SelectionListener<T> listener)
    {
        if(listener == null)
            throw new NullPointerException("invalid argument - null is no valid listener");

        listeners.add(listener);
    }

    protected void fireNotification(String option)
    {
        Character[] toChar = new Character[option.length()];
        for(int i = 0 ; i < option.length() ; i++)
            toChar[i] = option.charAt(i);

        //break off if the selected option is no valid option
        //example: uncomplete key
        if(!possibleSelections.hasPath(toChar))
            return;

        T selected = possibleSelections.get(toChar);

        listeners.forEach(l -> l.selected(new SelectionEvent<>(selected)));
    }

    /////////////////////////////////////////////////////////////////
    // exception handling
    /////////////////////////////////////////////////////////////////

    private SearchBoxExceptionHandler handler = (e -> {throw e;});

    private ExceptionPolicy policy = ExceptionPolicy.CORRECT_IF_POSSIBLE;

    private boolean searchComboBoxAvailable = true;

    private Runnable globalStop = (() -> System.exit(1));

    protected void handleException(Exception e , String msg , InternalExceptionCause cause)
    {
        SearchBoxInternalException exception = new SearchBoxInternalException(e , msg);

        switch (policy)
        {
            case CORRECT_IF_POSSIBLE:

                switch (cause)
                {
                    case POLICY_NOT_AVAILABLE:
                        policy = ExceptionPolicy.CORRECT_IF_POSSIBLE;
                        break;

                    case  FONTMETRICS_NOT_AVAILABLE:
                        if(!fixFontMetrics())
                            handler.exceptionThrown(exception);
                        break;

                    case UNKNOWN:
                        handler.exceptionThrown(exception);
                        break;
                }
                break;

            case STOP_PROCESS:
                searchComboBoxAvailable = false;

                if(currentUpdater != null)
                {
                    currentUpdater.stop();
                }

                break;

            case GLOBAL_STOP:
                globalStop.run();
                break;

            case NOTIFY_AND_CONTINUE:
                Dialogs.showDialog("Internal Exception", msg, JOptionPane.ERROR_MESSAGE,
                        new String[]{"OK"}, new String[]{}, this, 0);
                break;

            default:
                break;
        }
    }

    /**
     * fixes the fontmetrics if an error occured due to some unknown reason
     * @return true, if successfully a fontmetricsobject could be created
     */
    private boolean fixFontMetrics()
    {
        Font f = getFont();
        FontMetrics metrics = this.fontMetrics;

        if(f == null)
        {
            f = new Font("Italic" , Font.PLAIN , 12);

            metrics = getFontMetrics(f);
        }

        if(metrics == null)
        {
            BufferedImage bi = new BufferedImage(0 , 0 , BufferedImage.TYPE_INT_RGB);

            Graphics g = bi.createGraphics();

            metrics = g.getFontMetrics(f);

            g.dispose();
        }

        fontMetrics = metrics;

        return (metrics == null);
    }

    public void setExceptionPolicy(ExceptionPolicy policy)
    {
        if(policy == null)
            handleException(new NullPointerException("invalid policy") ,
                    "the exceptionpolicy must always be a valid value" ,
                    InternalExceptionCause.POLICY_NOT_AVAILABLE);

        this.policy = policy;
    }

    public void setGlobalStopBehaviour(Runnable r)
    {
        if(r == null)
            handleException(new NullPointerException("null not allowed here - a behaviour must be specified") ,
                    "null is not a valid behaviour" , InternalExceptionCause.UNKNOWN);

        globalStop = r;
    }

    public void setInternalExceptionHandler(SearchBoxExceptionHandler h)
    {
        if(h == null)
            handleException(new NullPointerException("invalid exceptionhandler") , "no handler specified" ,
                    InternalExceptionCause.UNKNOWN);

        handler = h;
    }

    public enum ExceptionPolicy
    {
        CORRECT_IF_POSSIBLE ,
        STOP_PROCESS ,

        /**
         * stops the complete process utilizing this
         * combobox-instance
         */
        GLOBAL_STOP ,

        /**
         * the process is continued and the exception
         * simply ignored - not recommended due to the hazard of severe errors
         */
        NOTIFY_AND_CONTINUE
    }

    enum InternalExceptionCause
    {
        FONTMETRICS_NOT_AVAILABLE ,
        INVALID_DATA_STRUCTURE ,
        POLICY_NOT_AVAILABLE ,
        UNKNOWN
    }
}