package dove.util.struct.tree;

public interface TreeModelChangeListener
{
    public void modelChanged(TreeModelChangedEvent arg);
}
