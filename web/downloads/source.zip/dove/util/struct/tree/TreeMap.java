package dove.util.struct.tree;

import java.util.*;

/**
 * creates a treemap that can be used
 * to relate every key to a value.
 *
 * @param <Key> every value can be accessed by an array of this type as key
 * @param <Val> Values saved
 */
public class TreeMap<Key , Val>
    extends Tree<Key>
{
    private Val val;

    private boolean valSet;

    private HashMap<Key , TreeMap<Key , Val>> childMap = new HashMap<>();

    public TreeMap(){
        valSet = false;
    }

    public TreeMap(Key key)
    {
        super(key);

        this.valSet = false;
    }

    private TreeMap(Key key , Val val){
        valSet = true;

        this.val = val;

        this.valSet = true;
    }

    public void insert(Key key , Val val)
    {
        childMap.put(key , new TreeMap(val));
    }

    public Val getVal(Key[] path)
    {
        TreeMap<Key , Val> node = this;

        for(Key key : path)
        {
            node = node.childMap.get(key);

            if(node == null)
                throw new NoSuchElementException("Invalid path, no element matches this path");
        }

        return node.val;
    }

    
    public int size() {
        int result = 0;

        ArrayList<Iterator<TreeMap<Key , Val>>> iterStack = new ArrayList<>();
        iterStack.add(childMap.values().iterator());

        while(!iterStack.isEmpty())
        {
            //TODO
        }

        return result;
    }

    public boolean isEmpty() {
        return childMap.isEmpty();
    }
    
    public boolean containsKey(Object key) {
        Key[] k;

        try{
            k = (Key[]) key;
        }catch (ClassCastException e)
        {
            return false;
        }

        TreeMap<Key , Val> node = this;

        for(Key nextKey : k)
        {
            node = node.childMap.get(nextKey);

            if(node == null)
                return false;
        }

        return true;
    }

    
    public boolean containsValue(Object value) {
        return false;
    }

    public boolean hasKey(Key[] k)
    {
        return super.hasPath(k);
    }
    
    public Val get(Key[] k) {
        Key[] key;

        try {
            key = (Key[]) k;
        }catch (ClassCastException e){return null;}

        TreeMap<Key , Val> node = this;

        for(Key nextKey : key)
        {
            node = node.childMap.get(nextKey);

            if(node == null)
                throw new NoSuchElementException("No element found with this key");
        }

        if(node.valSet)
            return node.val;
        else
            throw new NoSuchElementException("This value is not set");
    }

    public Val put(Key[] key, Val value) {
        Val temp = null;

        if(hasKey(key))
            temp = get(key);

        TreeMap<Key , Val> node = this;

        for(Key k : key)
        {
            TreeMap next = node.childMap.get(k);

            if(next == null)
            {
                next = new TreeMap(k);

                node.childMap.put(k , next);
                try {
                    node.add(next);
                }catch (TreeBuildException ignored){}//never thrown --> ignore
            }

            node = next;
        }

        node.val = value;
        node.valSet = true;

        return temp;
    }
    
    public void remove(Key[] key)
    {
        TreeMap n = (TreeMap) getNodeForPath(key);

        n.valSet = false;
    }

    
    public void putAll(Map<? extends Key[] , ? extends Val> m) {
        m.entrySet().forEach(e -> put(e.getKey() , e.getValue()));
    }

    
    public void clear() {
        childMap.clear();

        super.clear();
    }
    
    public boolean equals(Object o) {
        if(!(o instanceof TreeMap))return false;

        if(o == this)return true;

        return ((super.equals(o) && ((TreeMap) o).childMap.equals(childMap)));
    }

    
    public int hashCode() {
        return childMap.hashCode();
    }

    public Tree<Key> keyTree()
    {
        Tree<Key> result = new Tree<>(null);

        ArrayList<Iterator<Map.Entry<Key , TreeMap<Key , Val>>>> entryIterStack = new ArrayList<>();
        entryIterStack.add(childMap.entrySet().iterator());

        ArrayList<Tree<Key>> productIterStack = new ArrayList<>();
        productIterStack.add(result);

        while(!entryIterStack.isEmpty())
        {
            Iterator<Map.Entry<Key , TreeMap<Key , Val>>> iter = entryIterStack.get(0);

            if(!iter.hasNext())
            {
                entryIterStack.remove(0);
                productIterStack.remove(0);
            }
            else
            {
                Map.Entry<Key , TreeMap<Key , Val>> nextEntry = iter.next();

                Tree<Key> nextNode = new Tree<>(nextEntry.getKey());

                try {
                    productIterStack.get(0).add(nextNode);
                }catch (TreeBuildException ignored){}

                productIterStack.add(0 , nextNode);

                entryIterStack.add(nextEntry.getValue().childMap.entrySet().iterator());
            }
        }

        return result;
    }

    public Tree<Val> valTree()
    {
        Tree<Val> result = new Tree<>();

        //TODO

        return result;
    }

    @Override
    public List<Key[]> listPaths()
    {
        ArrayList<Key[]> paths = new ArrayList<>();

        class SearchPaths
            extends GoThroughManager<TreeMap<Key , Val>>
        {
            @Override
            public void accept(TreeMap<Key, Val> tTree) {
                if(tTree.valSet)
                    paths.add(tTree.getPath());
            }
        }

        goThroughTree(this , new SearchPaths());

        return paths;
    }
}