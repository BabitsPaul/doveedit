package dove.util.struct.tree;

import java.io.Serializable;
import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.Stream;

/**
 * provides a tree-structure for
 * collecting and storing data
 *
 * this tree is an implementation of multitree
 *
 * List of logical rules this tree follows:
 * <ul>
 *     <li>
 *         1. The list of children is a set
 *              every Tree.content occures maximum once per list
 *              of children
 *     </li>
 *     <li>
 *         2. To ensure a correct structure
 *              (no circles, etc.), every node is only allowed to
 *              have exactly one parent, multiple parents are prohibited
 *     </li>
 *     <li>
 *         3. To furthermore ensure structural stability, the contents of the nodes
 *              may not be changed, once they are part of the tree (remove-operations excluded)
 *     </li>
 *     <li>
 *         4. The root doesn't hold any content and is ignored in all methods
 *              using a path-variable, like insert at path-end, hasPath, etc.
 *     </li>
 *     <li>
 *         5. Every T t may only once be part of a list of peers.
 *              <code>
 *                  Tree<T> tree = ?;
 *                  Tree<T> parent = tree.parent;
 *                  parent.remove(tree);
 *                  return parent.children.stream().findAny(t ->
 *                      t.content.equals(tree.content).isPresent();
 *              </code>
 *              must always return false.
 *     </li>
 *     <li>
 *         6. All algorithms that run through the tree in some
 *          way run through the tree inorder (bottom top - right to left)
 *     </li>
 * </ul>
 *
 * @param <T> typeparameter for
 *           the content of this treeelement
 */

@SuppressWarnings("unchecked")
public class Tree<T>
    implements Comparable<Tree<T>> ,
        Serializable ,
        Iterable ,
        Cloneable
{
    public static final long serialVersionUID = -329877773592931935L;

    /**
     * the parent of this treeelement
     * every node can only be inserted once
     */
    private Tree<T> parent;

    /**
     * the content-element of this node
     */
    public T content;

    /**
     * the children of this treeelement
     * any collection can be used with the restrictions specified by
     * the rules mentioned above
     */
    protected Collection<Tree<T>> children;

    /**
     * a list of
     * listeners to this treemodel
     */
    private final ArrayList<TreeModelChangeListener> modelChangeListeners;

    /**
     * content flag
     * this flag shows wether the content is set or there exists
     * no valid content for this node
     */
    private boolean contentSet;

    /**
     * creates a new instance of Tree
     * with t as content
     *
     * @param t content of the new Treeelement
     */
    public Tree(T t)
    {
        content = t;

        children = new ArrayList<>();

        modelChangeListeners = new ArrayList<>();

        contentSet = true;
    }

    /**
     * creates a new treenode without content
     */
    public Tree()
    {
        children = new ArrayList<>();

        modelChangeListeners = new ArrayList<>();

        contentSet = false;
    }

    //--------------------------------------------
    //insert remove
    //--------------------------------------------

    /**
     * inserts the child as a new
     * node to the tree with this node as parent
     *
     * @param child element to insert
     * @throws TreeBuildException if any structural rules are broken (see classdef)
     */
    public Tree<T> add(T child)
        throws TreeBuildException
    {
        return add(new Tree<>(child));
    }

    /**
     * inserts child as node of the tree
     * with this treeelement as parent
     *
     * @param child the node to insert
     * @throws TreeBuildException if any structural rules are broken (see classdef)
     */
    public Tree<T> add(Tree<T> child)
        throws TreeBuildException
    {
        //any node is only allowed to be inserted once
        //(see structural rules)
        if(child.parent != null)
            throw new TreeBuildException("Element is already element of the tree");

        children.add(child);

        child.parent = this;

        fireModelChanged(TreeModelChangedEvent.TYPE.ADD);

        return child;
    }

    /**
     * if the path isn't yet a part of the tree, all
     * nodes of the path, that aren't existent, will be
     * created and inserted in the tree
     *
     * @param path the path that should be completed
     */
    public void completePath(T[] path)
    {
        Tree<T> child = this;

        for(T node : path)
        {
            boolean found = false;

            for (Tree<T> t : child.children) {
                if (t.content.equals(node))
                {
                    child = t;

                    found = true;
                }
            }

            if(!found)
            {
                try {
                    child.add(node);
                }catch (TreeBuildException ignored)
                {
                    //this exception will never be thrown, since
                    //there exists no child with content 'node'
                    //(proven by check in the for-loop : child.children)
                }
            }
        }

        fireModelChanged(TreeModelChangedEvent.TYPE.ADD);
    }

    /**
     * inserts the node at the end of the specified path
     * any nodes, that don't exist are automatically created
     *
     * the path starts directly after the root-element and
     * ends one level before the node
     * (node.content is no element of the path)
     *
     * @param path the path from the root to the node (exclusive both)
     * @params node the node to insert
     *
     * @throws dove.util.struct.tree.TreeBuildException if any of the structural rules of
     *      this type of tree is broken
     */
    public void insertAtPathEnd(T[] path , Tree<T> node)
        throws TreeBuildException
    {
        if(node.getParent() != null)
            throw new TreeBuildException("Invalid tree state - this node already is content of the tree");

        Tree<T> curNode = getRoot();

        for(T t : path)
        {
            //search for a child of this node
            //so that child.content.equals(nextPathElement)
            Optional<Tree<T>> search = curNode.children.stream().
                    filter((Tree<T> child) -> (child.content.equals(t))).
                    findFirst();

            if(search.isPresent())
            {
                //node found that matches the path
                curNode = search.get();
            }else
            {
                //pathelement doesn't exists
                //needs to be created and inserted
                Tree<T> newNode = new Tree<>(t);

                newNode.parent = curNode;

                curNode = newNode;

                children.add(newNode);
            }
        }

        //parentnode of the node to insert
        //is curNode
        if(children.stream().
                filter((Tree<T> child) -> (child.content.equals(node.content))).
                findFirst().isPresent())
            throw new TreeBuildException("Node already exists");
            //a node with this content already is content of this tree

        //set nodes parent to the last node in
        //the path before node
        node.parent = curNode;

        //register node as a child of this TreeElement
        curNode.children.add(node);

        //notify listeners about modelchange
        fireModelChanged(TreeModelChangedEvent.TYPE.ADD);
    }

    /**
     * returns the content of this node
     * if it is set
     *
     * @return the content of this node
     * @throws java.util.NoSuchElementException if the content is not set
     */
    public T getContent() {
        if(!contentSet)
            throw new NoSuchElementException("no content set");

        return content;
    }

    /**
     * creates a read-only copy of children to grant
     * access to the treestrucutre without the danger of
     * damaging the structural integrity of this tree
     *
     * @return a read-only copy of children
     *
     * @see java.util.Collections#unmodifiableCollection
     */
    public Collection<Tree<T>> getChildren()
    {
        return Collections.unmodifiableCollection(children);
    }

    /**
     * @return true if the content is currently a valid value
     */
    public boolean contentSet()
    {
        return contentSet;
    }

    /**
     * sets the content for this node
     * and sets the contentSetFlag
     *
     * @param nt the new content
     */
    public void setContent(T nt)
    {
        contentSet = true;

        content = nt;
    }

    /**
     * removes all nodes from the tree
     * which have a content equal to childVal
     * and are children of this node
     *
     * afterwards the treestructure is updated
     *
     * @param childVal value to remove
     */
    public void remove(T childVal)
    {
        Stream<Tree<T>> matchingChildStream = children.stream().
                filter((Tree<T> child) -> (child.content.equals(childVal)));

        class CheckAllEmpty
            extends GoThroughManager<Tree<T>>
        {
            private boolean noSet = true;

            @Override
            public void accept(Tree<T> tTree) {
                noSet &= !tTree.contentSet;
            }

            @Override
            public boolean breakOff() {
                return !noSet;
            }
        }

        matchingChildStream.forEach(n -> {
            n.contentSet = false;

            CheckAllEmpty c = new CheckAllEmpty();
            goThroughTree(n , c);

            if(c.noSet)
                children.remove(n);
        });

        if(matchingChildStream.findAny().isPresent())
            fireModelChanged(TreeModelChangedEvent.TYPE.REMOVE);
    }

    /**
     * removes the given node from te tree
     *
     * @param child the node to remove
     * @return true if successful
     */
    public boolean removeSubtree(Tree<T> child)
    {
        boolean temp = children.remove(child);

        if(temp) {
            child.parent = null;

            fireModelChanged(TreeModelChangedEvent.TYPE.REMOVE);
        }

        return temp;
    }

    /**
     * clears this subtree
     *
     * during this operation, all known relationships between the nodes
     * of this subtree will be released
     */
    public void clear()
    {
        ArrayList<Tree<T>> nodes = new ArrayList<>();


        nodes.addAll(children);
        while(!nodes.isEmpty())
        {
            Tree<T> temp = nodes.get(0);

            nodes.addAll(temp.children);

            temp.getParent().removeSubtree(temp);
            temp.parent = null;
        }
    }

    /**
     * merges this tree with the given tree, starting from the root
     * of toMerge and the node which calls merge
     *
     * rules:
     * <ol>
     *     <li>
     *         the content of the rootnode of toMerge MUST be equal with the content of the callernode (this)
     *     </li>
     *     <li>
     *         this node MUST NOT be a subtree of the tree to which the callernode belongs
     *     </li>
     * </ol>
     *
     * @param toMerge the tree that is merged with this tree
     * @throws dove.util.struct.tree.TreeBuildException if any of the above rules are broken.
     */
    public void merge(Tree<T> toMerge)
        throws TreeBuildException
    {
        if(!toMerge.content.equals(content))
            throw new TreeBuildException("Invalid merge-operation, toMerge doesn't fit this tree");

        ArrayList<Iterator<Tree<T>>> toMergeIterStack = new ArrayList<>();
        toMergeIterStack.add(toMerge.children.iterator());

        ArrayList<Collection<Tree<T>>> internalCheckStack = new ArrayList<>();
        internalCheckStack.add(children);

        ArrayList<Tree<T>> internalParentStack = new ArrayList<>();
        internalParentStack.add(this);

        while(!toMergeIterStack.isEmpty())
        {
            Iterator<Tree<T>> mergeIter = toMergeIterStack.get(0);
            if(!mergeIter.hasNext())
            {
                toMergeIterStack.remove(0);
                internalCheckStack.remove(0);
                internalParentStack.remove(0);
            }else

            {
                Tree<T> nextMerge = mergeIter.next();

                Optional<Tree<T>> equalFound = internalCheckStack.get(0).stream()
                        .filter(t -> t.content.equals(nextMerge.content)).findAny();

                if(equalFound.isPresent())
                {
                    toMergeIterStack.add(0 , nextMerge.children.iterator());
                    internalCheckStack.add(0 , equalFound.get().children);
                    internalParentStack.add(0 , equalFound.get());
                }else
                {
                    internalParentStack.get(0).add(nextMerge.copy());
                }
            }
        }
    }

    //---------------------------------------------------
    //treeop
    //---------------------------------------------------

    /**
     * this method evaluates the treeelement that
     * is the root of the tree of which this object
     * is an element
     *
     * @return the root of the tree
     */
    public Tree<T> getRoot()
    {
        Tree<T> temp = this;

        while(temp.parent != null)
            temp = temp.parent;

        return temp;
    }

    /**
     * @return the path from the root to the current node
     */
    public T[] getPath()
    {
        T[] result = (T[]) Array.newInstance(content.getClass() , getLevel() - 1);

        Tree<T> node = this;
        for(int i = result.length - 1 ; i >= 0 ; i--)
        {
            result[i] = node.content;

            node = node.parent;
        }

        return result;
    }

    /**
     * checks whether this path is content of the
     * tree
     *
     * the root is not included in this path
     *
     * @param path a path through the tree
     * @return true if the path is content of the tree
     */
    public boolean hasPath(T[] path)
    {
        Tree<T> node = getRoot();

        for(T t : path)
        {
            Optional<Tree<T>> search = node.children.stream()
                    .filter((Tree<T> child) -> (child.content != null && child.content.equals(t)))
                    .findAny();

            if(search.isPresent())
                node = search.get();
            else
                return false;
        }

        return true;
    }

    /**
     * gets the node of the tree that is at the end of the specified path
     * the path always starts at the root, no matter from where in the tree
     * the method is called
     *
     * @param path the path from the root to the node
     * @return the node at the end of the path
     * @throws java.util.NoSuchElementException if the path doesn't exist
     *      (a element in the path isn't part of the tree, etc.)
     */
    public Tree<T> getNodeForPath(T[] path)
        throws NoSuchElementException
    {
        Tree<T> curNode = this;

        for(T t : path)
        {
            Optional<Tree<T>> search = curNode.children.stream().
                    filter((Tree<T> child) -> (child.content.equals(t))).
                    findFirst();

            if(search.isPresent())
                curNode = search.get();
            else
                throw new NoSuchElementException("Invalid path - Element not found: " + t.toString());
        }

        return curNode;
    }

    /**
     * the root has level = 0
     * any other treenode gets its level
     * by the length of the path from the root
     * to the node
     *
     * @return the level of the current node in the tree
     */
    public int getLevel()
    {
        Tree<T> node = this;

        int result = 0;

        while(node.parent != null)
        {
            result++;

            node = node.parent;
        }

        return result;
    }

    /**
     * @return the level of the node with the highest level
     */
    public int getHeight()
    {
        class DepthCounter
            extends GoThroughManager
        {
            int maxDepth = 0;

            @Override
            public void levelChanged(Integer i)
            {
                if(i > maxDepth)
                    maxDepth = i;
            }
        }

        DepthCounter depth = new DepthCounter();
        goThroughTree(getRoot() , depth);

        return depth.maxDepth;
    }

    /**
     * @return the total number of elements in this tree
     */
    public int size()
    {
        //this consumer increments size
        //every time it consumes a node
        class SizeCounter
            extends GoThroughManager<Tree<T>>
        {
            int size = 0;

            public void accept(Tree<T> t)
            {
                ++size;
            }
        }

        SizeCounter counter = new SizeCounter();
        //run through the tree and count all nodes
        goThroughTree(getRoot() , counter);

        return counter.size;
    }

    /**
     * checks whether this node is
     * the root of a tree
     *
     * @return true if the node is a root
     */
    public boolean isRoot(){return (parent == null);}

    /**
     * checks whether this node has any
     * children
     *
     * @return <code>true</code> if the node has no children
     */
    public boolean isLeaf(){return children.isEmpty();}

    /**
     * @return the parent of this leaf
     */
    public Tree<T> getParent()
    {
        return parent;
    }

    /**
     * returns the root of the smallest common subtree
     * this tree contains both the node calling the method and
     * t and there cannot be found any smaller subtree that contains
     * both nodes
     *
     * @param t the node for which a common subtree is searched
     * @return the smallest commmon subtree
     */
    public Tree<T> smallestCommonSubtree(Tree<T> t)
    {
        if(!getRoot().contains(t))
            throw new IllegalArgumentException("argument is no member of this tree");

        Iterator<Tree<T>> tIter = t.listParents().iterator();
        Iterator<Tree<T>> internalIter = t.listParents().iterator();

        Tree<T> temp = null;
        Tree<T> prev;

        while(tIter.hasNext() && internalIter.hasNext())
        {
            prev = temp;

            temp = tIter.next();

            if(!temp.content.equals(internalIter.next().content))
                return prev;
        }

        return null;
    }

    ///////////////////////////////////////////////////////////////////////
    // list ops
    ///////////////////////////////////////////////////////////////////////

    /**
     * lists all parents of this node
     * down to the root
     * (includes this node)
     *
     * order is from the root to this node
     *
     * @return a list of nodes which are part of the path from this node to the root
     */
    public List<Tree<T>> listParents()
    {
        List<Tree<T>> result = new ArrayList<>();

        Tree<T> temp = this;

        while(temp != null)
        {
            result.add(temp);
            temp = temp.getParent();
        }

        Collections.reverse(result);

        return result;
    }

    /**
     * lists all peers of this node
     * peers of this node have the following
     * attributes in common:
     * <ul>
     *     <li>same parent</li>
     *     <li>same level</li>
     * </ul>
     *
     * @return a collection of the peers of this list
     */
    public Collection<Tree<T>> listPeers()
    {
        if(getParent() == null)
        {
            try {
                Collection<Tree<T>> result = children.getClass().newInstance();
                result.add(this);
                return result;
            }catch (InstantiationException | IllegalAccessException e){
                ArrayList<Tree<T>> result = new ArrayList<>();
                result.add(this);
                return result;
            }
        }

        return getParent().children;
    }

    /**
     * lists all nodes with content that either equals t,
     * or, if a comparator is provided, equals the provided comparator
     *
     * @param t the T for wich nodes with equal content are searched
     * @param comp an optional comparator to compare the nodecontents with t
     * @return a list of nodes with content equal to t
     */
    public Collection<Tree<T>> listMatching(T t , Comparator<T>... comp)
    {
        Collection<Tree<T>> matches = new Stack<>();

        Comparator<T> c;

        if(comp.length > 0)
            c = comp[0];
        else
            c = (o1, o2) -> {
                if(o1 == o2)
                    return 0;
                if(o1 == null)
                    return 1;
                else if(o2 == null)
                    return -1;
                else if(o1.equals(o2))
                    return 0;
                else
                    return -1;
            };

        class MatchesSearch
            extends GoThroughManager<Tree<T>>
        {
            @Override
            public void accept(Tree<T> tTree) {
                if(c.compare(tTree.content , t) == 0)
                    matches.add(tTree);
            }
        }

        MatchesSearch search = new MatchesSearch();
        goThroughTree(this , search);

        return matches;
    }

    /**
     * lists the roots of all subtrees containing path
     *
     * @param path the path that is searched
     * @return a list of nodes
     */
    public List<Tree<T>> listMatchingPaths(T[] path)
    {
        if(path.length == 0)
            throw new IllegalArgumentException("invalid path - minimum path length = 1");

        List<Tree<T>> matches = new ArrayList<>();

        Collection<Tree<T>> startNodeMatch = listMatching(path[0]);

        startNodeMatch.forEach(t -> {
            Tree<T> helper = new Tree<>();
            helper.children.add(t);

            if(helper.hasPath(path))
                matches.add(t);
        });

        return matches;
    }

    /**
     * lists all children of this tree inorder
     * - from root to leafs
     * - the way the content is sorted on each level
     *      depends on the collection the children are stored
     *      in
     *
     * @see Tree#goThroughTree(dove.util.struct.tree.Tree, dove.util.struct.tree.Tree.GoThroughManager<Tree<T>>)
     * @return a list of the contents of this tree sorted inorder
     */
    public List<T> listContent()
    {
        class ListContent
                extends GoThroughManager<Tree<T>>
        {
            ArrayList<T> nodes = new ArrayList<>();

            public void accept(Tree<T> t)
            {
                if(t.contentSet)
                    nodes.add(t.content);
            }
        }

        ListContent list = new ListContent();
        goThroughTree(getRoot() , list);

        return list.nodes;
    }

    /**
     * lists all nodes of this tree
     * @see Tree#goThroughTree(dove.util.struct.tree.Tree, dove.util.struct.tree.Tree.GoThroughManager)
     *
     * @return a list of nodes
     */
    public List<Tree<T>> listNodes()
    {
        class ListNodes
                extends GoThroughManager<Tree<T>>
        {
            ArrayList<Tree<T>> nodes = new ArrayList<>();

            @Override
            public void accept(Tree<T> t)
            {
                nodes.add(t);
            }
        }

        ListNodes list = new ListNodes();
        goThroughTree(this , list);

        return list.nodes;
    }

    /**
     * lists all leafs of this tree
     *
     * @return a list of leafs of this trees
     */
    public List<Tree<T>> listLeafs()
    {
        class ListLeafs
                extends GoThroughManager<Tree<T>>
        {
            ArrayList<Tree<T>> found = new ArrayList<>();

            @Override
            public void accept(Tree<T> t)
            {
                if(t.children.isEmpty())
                    found.add(t);
            }
        }

        ListLeafs temp = new ListLeafs();
        goThroughTree(this , temp);

        return temp.found;
    }

    /**
     * this iterator for the current tree
     * runs through the tree inorder
     * - direction from root to leafs
     * - the way the content is sorted per level
     *      depends on the collection used for storing
     *      the children
     *
     * @return an iterator for this tree
     */
    @Override
    public Iterator iterator() {
        return new TreeIter(this);
    }

    /**
     * lists all paths in this tree
     *
     * @return a list of T[]
     */
    public List<T[]> listPaths()
    {
        List <T[]> paths = new ArrayList<>();

        List<Tree<T>> leafs = listLeafs();

        for(Tree<T> leaf : leafs)
            paths.add(leaf.getPath());

        return paths;
    }

    /**
     * makes this tree disjoint of t
     * (has no subtrees in common with t)
     *
     * @param t
     */
    public void disjoint(Tree<T> t)
    {
        /**
         * pseudocode:
         *
         * internalNode = first child of this node;
         * alienNode;
         *
         * if internalNode has children
         *      alienNode = findMatchingAlienChild
         *
         *      if matching alienNode found
         *          internalNode = frst child of internalNode
         *
         *      else if peer of internalNode available
         *          internalNode = next peer of internalNode
         *
         *      else
         *          internalNode = parent of internalNode
         * else
         *      alienNode = findMatchingAlienChild
         *
         *      if matching alienNode found
         *          remove internalNode
         *      else
         *          internalNode = parent of internalNode
         *
         * if internalNode == null
         *      end process
         * else
         *      repeat
         */

        if(t == null)
            throw new NullPointerException("invalid argument - null not allowed here");

        if(!t.content.equals(content))
            return;

        Tree<T> localNode = this;
        Tree<T> alienMatch = t;

        ArrayList<Iterator<Tree<T>>> alienPossibleMatches = new ArrayList<>();
        alienPossibleMatches.add(alienMatch.children.iterator());

        while(!alienPossibleMatches.isEmpty())
        {

        }
    }


    //------------------------------------------------
    // tree analysation helper
    //------------------------------------------------

    /**
     * goes through this subtree (with startNode as root) inorder
     *
     * rules for running through the tree:
     * <ul>
     *     <li>
     *         1. if the algorithm can go one level deeper
     *              it will go one level deeper
     *     </li>
     *     <li>
     *         2. if the algorithm can't go any deeper
     *              on it's current path, it will go on
     *              with the next child of this node's parent
     *     </li>
     *     <li>
     *         3. if all nodes on a level with the same parent are
     *              processed, the algorithm steps one level back
     *     </li>
     *     <li>
     *         4. if <code>mgr.breakOff()</code> returns true,
     *              the algorithm will break off
     *     </li>
     * </ul>
     *
     * @see dove.util.struct.tree.Tree.GoThroughManager
     *
     * @param startNode the root of the subtree to analyse
     * @param mgr the manager defining the go through conditions
     */
    protected void goThroughTree(Tree<T> startNode , GoThroughManager<? extends Tree<T>> mgr)
    {
        //levelcounter
        int level = 0;

        //the current node used during analysis of the tree
        Tree<T> node;

        //a stack representing the path to the current subtree
        //of the tree which is processed
        ArrayList<Iterator<Tree<T>>> stack = new ArrayList<>();

        //set startnode
        ArrayList<Tree<T>> temp = new ArrayList<>();
        temp.add(startNode);

        //insert the root as startvalue
        stack.add(0 , temp.iterator());

        //run through the tree as long as there are any nodes
        //remaining unconsumed
        while(!stack.isEmpty() && !mgr.breakOff())
        {
            if(!stack.get(0).hasNext())
            {
                //nothing to process in this subtree
                //step back and continue on the next level
                stack.remove(0);

                level -= 1;

                mgr.levelChanged(level);
            }
            else
            {
                //still nodes remaining to process in this subtree
                node = stack.get(0).next();

                //process current node
                mgr.nextNode(node);

                //go one level deeper, if any children
                //are available
                if(!node.isLeaf())
                {
                    stack.add(0 , node.children.iterator());

                    level += 1;

                    mgr.levelChanged(level);
                }
            }
        }
    }

    /**
     * defines all operations needed during
     * @see Tree#goThroughTree(dove.util.struct.tree.Tree, dove.util.struct.tree.Tree.GoThroughManager)
     * to define the way, the algorithm runs through the tree
     *
     * this class can be overrided, to analyse the tree
     * (compare getHeight() or listNodes())
     */
    protected class GoThroughManager<N extends Tree<T>>
    {
        /**
         * workaround to make accept available for trees
         * (issues with generics)
         *
         * @param tree handed on to accept
         */
        public final void nextNode(Tree<T> tree)
        {
            try {
                accept((N) tree);
            }catch (ClassCastException e)
            {
                throw new IllegalArgumentException(tree.getClass().getName() + " cannot be processed (invalid class)");
            }
        }

        /**
         * called for every node
         * this method can be overriden, in order to analyse the
         * tree
         *
         * @param tTree the node to be processed
         */
        public void accept(N tTree)
        {
            //stub override to use
            //called for each node
        }

        /**
         * this method is called if goThroughTree
         * goes one level deeper / higher whilst running through
         * the tree
         *
         * @param integer the level, the algorithm currently is running through
         */
        public void levelChanged(Integer integer)
        {
            //stub
            //override to use
            //called each time, the algorithm goes a level
            //deeper or higher
        }

        /**
         * this method is checked in every loop runthrough
         * of Tree.goThroughTree(...)
         * if this method returns true, the algorithm will break off
         *
         * @return true if the algorithm should break off
         */
        public boolean breakOff()
        {
            //stub
            //override to use
            //called in each looprunthrough to
            //check whether run on or stop
            return false;
        }
    }

    //------------------------------------------------
    //search
    //------------------------------------------------

    /**
     * searches for the first node which has a
     * content matching t found by
     * Tree.goThroughTree(...)
     *
     * @see Tree#goThroughTree(dove.util.struct.tree.Tree, dove.util.struct.tree.Tree.GoThroughManager)
     *
     * @param t the value to search
     * @return the first node with matching content
     */
    public Tree<T> searchAnyNodeFor(T t)
    {
        return searchAnyNodeFor((T a , T b) -> (a.equals(b) ? 0 : 1) , t);
    }

    /**
     * searches for the first component in the
     * tree matching the comparator
     *
     * @param compare with this comparator, nodes are checked
     *                for fullfilling the conditions
     * @param t the value that is searched
     * @return the first node matching the conditions
     */
    public Tree<T> searchAnyNodeFor(Comparator<T> compare , T t)
    {
        class SearchMgr
            extends GoThroughManager<Tree<T>>
        {
            Tree<T> found;

            public void accept(Tree<T> tree)
            {
                if(!tree.contentSet)
                    return;

                if((compare.compare(tree.content , t) == 0))
                    found = tree;
            }

            public boolean breakOff()
            {
                return (found != null);
            }
        }

        SearchMgr mgr = new SearchMgr();
        goThroughTree(getRoot() , mgr);

        return mgr.found;
    }

    /**
     * lists all nodes found in the tree
     * with content equal t
     *
     * @param t the value to search
     * @return a list of nodes
     */
    public ArrayList<Tree<T>> searchAllNodesFor(T t)
    {
       return searchAllNodesFor((T a, T b) -> (a.equals(b) ? 0 : 1), t);
    }

    /**
     * lists all nodes which are equal to t
     * comparisons are done via <code>compare.compare</code>
     *
     * @see Tree#goThroughTree(dove.util.struct.tree.Tree, dove.util.struct.tree.Tree.GoThroughManager)
     *
     * @param compare with this comparator, nodes are checked
     *                for fullfilling the conditions
     * @param t the value that is searched
     * @return a list of treenodes matching conditions
     */
    public ArrayList<Tree<T>> searchAllNodesFor(Comparator<T> compare , T t)
    {
        class SearchMgr
                extends GoThroughManager<Tree<T>>
        {
            ArrayList<Tree<T>> found = new ArrayList<>();

            public void accept(Tree<T> tree)
            {
                if(compare.compare(tree.content , t) == 0)
                    found.add(tree);
            }
        }

        SearchMgr mgr = new SearchMgr();
        goThroughTree(getRoot() , mgr);

        return mgr.found;
    }

    /**
     * this algorithm searches in the tree
     * for the first node from which a path
     * equal to pathpiece starts
     *
     * @param pathPiece the piece of a path you're searching
     * @return the first node fitting this path
     */
    public Tree<T> searchForPathPiece(T[] pathPiece)
    {
        //check for valid path
        if(pathPiece.length == 0)
            throw new IllegalArgumentException("no valid path (minimum length = 1)");

        //the current node used during analysis of the tree
        Tree<T> node;

        //a stack representing the path to the current subtree
        //of the tree which is processed
        ArrayList<Iterator<Tree<T>>> stack = new ArrayList<>();

        //set startnode
        ArrayList<Tree<T>> temp = new ArrayList<>();
        temp.add(getRoot());

        //insert the root as startvalue
        stack.add(0 , temp.iterator());

        //run through the tree as long as there are any nodes
        //remaining unconsumed
        while(!stack.isEmpty())
        {
            if(!stack.get(0).hasNext())
            {
                //nothing to process in this subtree
                //step back and continue on the next level
                stack.remove(0);
            }
            else
            {
                //still nodes remaining to process in this subtree
                node = stack.get(0).next();

                if(node.hasPath(pathPiece))
                    return node;

                //process current node

                //go one level deeper, if any children
                //are available
                if(!node.isLeaf())
                {
                    stack.add(0 , node.children.iterator());
                }
            }
        }

        return null;
    }

    //------------------------------------------------
    //toString
    //------------------------------------------------

    /**
     * creates a Stringrepresentation of the subtree
     * with the current node as child
     *
     * Output:
     * <pre>
     * root
     *      level1nodeA
     *          level2nodeA
     *      level1nodeB
     *          level2nodeB
     *          level2nodeC
     * </pre>
     *
     * @see Object#toString()
     * @see Tree#goThroughTree(dove.util.struct.tree.Tree, dove.util.struct.tree.Tree.GoThroughManager)
     * @see dove.util.struct.tree.Tree.GoThroughManager
     *
     * @return a string representation of this tree
     */
    @Override
    public String toString()
    {
        class StringBuild
            extends GoThroughManager<Tree<T>>
        {
            StringBuilder builder = new StringBuilder();

            int level = 0;

            public void accept(Tree<T> t)
            {
                builder.append('\n');
                builder.append(createInsertion());
                builder.append(t.getStringRep());
            }

            private char[] createInsertion()
            {
                char[] result = new char[level];

                for(int i = 0 ; i < level ; i++)
                    result[i] = '\t';

                return result;
            }

            public void levelChanged(Integer newLevel)
            {
                level = newLevel;
            }
        }

        StringBuild build = new StringBuild();
        goThroughTree(this , build);

        return build.builder.substring(1);
    }

    /**
     * Creates a String as Representation of the node
     * used in @see dove.util.struct.tree.Tree#toString()
     * override to change result of the toString method
     *
     * @return representation of the node
     */
    protected String getStringRep()
    {
        if(!contentSet) {
            return "";
        }else if(content == null)
        {
            return "null";
        }else{
            return content.toString();
        }
    }

    //------------------------------------------------------
    //dove.event handling
    //------------------------------------------------------

    /**
     * adds a new listener to the tree
     * if any changes to the model happen (insert/remove)
     * the listener will be updated
     *
     * @param updater the new listener
     */
    public void addModelChangedListener(TreeModelChangeListener updater)
    {
        modelChangeListeners.add(updater);
    }

    /**
     * removes the listener
     * this listener will no longer be updated if any changes
     * occure on the tree
     *
     * @param updater the listener to remove
     */
    public void removeModelChangedListener(TreeModelChangeListener updater)
    {
        modelChangeListeners.remove(updater);
    }

    /**
     * notifys every listener, that the model
     * has been modified (node inserted/removed)
     *
     * @see dove.util.struct.tree.TreeModelChangedEvent.TYPE
     * @param type the type of changed performed
     */
    protected void fireModelChanged(TreeModelChangedEvent.TYPE type)
    {
        modelChangeListeners.forEach(l -> l.modelChanged(new TreeModelChangedEvent(Tree.this, type)));
    }

    //-------------------------------------------------------------
    //compare
    //-------------------------------------------------------------

    /**
     * checks whether o is equal to <code>this</code>
     * returns true <code>if</code>:
     * - this == o
     * - o is an instance of <code>Tree<T></code> and
     *      the lists of children are equal aswell
     *
     * @param o compare to this object
     * @return true if o fullfills one of the conditions
     *      listed above
     */
    @Override
    public boolean equals(Object o)
    {
        if(o == this)
            return true;

        if(!(o instanceof Tree))
            return false;//wrong type

        Tree tree = (Tree) o;

        return
            (tree.content.equals(((Tree) o).content) &&
                children.equals(((Tree) o).children));
    }

    /**
     * compares this treenode to another node
     * returns:
     * - 0 <code>if(this.equals(tree))</code>
     * - content.compareTo(tree.content) <code>if(content instanceof Comparable)</code>
     * - getLevel() - tree.getLevel() <code>if(!(content instanceof Comparable)</code>
     *
     * @see Comparable
     *
     * @param tree the other node
     * @return the comparator-value
     */
    @Override
    public int compareTo(Tree<T> tree) {
        if(content instanceof Comparable)
        {
            //contents can be compared
            return ((Comparable<T>) content).compareTo(tree.content);
        }else{
            if(equals(tree))
                //equal node
                return 0;

            //content can't be compared --> compare level
            return getLevel() - tree.getLevel();
        }
    }

    /**
     * the hashcode of every node is created from
     * the content-hash XOR children-hash
     *
     * @return the hashcode for this object
     */
    @Override
    public int hashCode()
    {
        return (content.hashCode() ^ children.hashCode());
    }

    //------------------------------------------------------------
    //clone
    //------------------------------------------------------------

    /**
     * creates a shallow copy of this tree
     * since cloning of the content is not allowed
     *
     * however any structural operations (not concerning the content)
     * will not affect any clones and reverse
     *
     * @return a shallow copy of this treeelement
     */
    @Override
    public Tree<T> clone()
        throws CloneNotSupportedException
    {
        //creates new instance of tree
        //with the same parameters like this tree
        Tree<T> clone = (Tree<T>) super.clone();

        //copy all children
        children.forEach((Tree<T> child) ->
            {
                try
                {
                    //register cloned children as children of
                    //the clone
                    clone.add(child.clone());
                }catch (TreeBuildException | CloneNotSupportedException e){
                    //shouldn't occure, since this tree has a
                    //valid structure (is checked during build of original tree)
                }
            });

        return clone;
    }

    /**
     * creates a copy of the current tree
     *
     * all nodes are newly created, contentobjects will be transferred
     * to the new tree (no copy)
     *
     * @return a copy of this tree
     */
    public Tree<T> copy()
    {
        class CopyMgr
            extends GoThroughManager<Tree<T>>
        {
            private Tree<T> result = new Tree<>(null);

            private Tree<T> currentParent = result;

            private Tree<T> lastAdded;

            private int currentLevel = 0;

            @Override
            public void accept(Tree<T> tTree) {
                try {
                    if(tTree.contentSet)
                    {
                        lastAdded = new Tree<>(tTree.content);
                    }else
                    {
                        lastAdded = new Tree<>();
                    }

                    currentParent.add(lastAdded);
                }catch (TreeBuildException e){
                    //never thrown
                }
            }

            @Override
            public void levelChanged(Integer integer) {
                if(currentLevel < integer)
                {
                    currentParent = lastAdded;
                }else
                {
                    currentParent = currentParent.getParent();
                }

                currentLevel = integer;
            }
        }

        CopyMgr mgr = new CopyMgr();

        goThroughTree(this , mgr);

        return mgr.result.children.iterator().next();
    }

    //------------------------------------------------------------
    //content check
    //------------------------------------------------------------

    /**
     * checks whether this node has a child containing
     * the value specified by t
     *
     * @param t the value to search
     * @return true if a child holds t as content
     */
    public boolean hasChild(T t)
    {
        return (children.stream().
                anyMatch((Tree<T> child) -> (
                                child.content.equals(t) && child.contentSet)
                ));
    }

    /**
     * checks whether alientree is contained inside this tree
     * the rules for this check are:
     *
     * the tree may contain other elements aswell, aslong
     * as the structure of the tree is part of this tree.
     *
     * the roots must have equal content.
     *
     * @param subTree the subtree that is searched
     * @return true if subTree is contained in the tree with this node as root
     */
    public boolean contains(Tree subTree)
    {
        //shows whether the content of this tree is still equal to the one
        //contained in subTree
        //updated in every step
        boolean contentValid = (content.equals(subTree.content));

        ArrayList<Collection<Tree<T>>> internalIterStack = new ArrayList<>();
        ArrayList<Iterator<Tree<Object>>> alienIterStack = new ArrayList<>();

        ArrayList<Tree<T>> internalHelper = new ArrayList<>();
        internalHelper.add(this);
        internalIterStack.add(internalHelper);

        ArrayList<Tree<Object>> alienHelper = new ArrayList<>();
        alienHelper.add(subTree);
        alienIterStack.add(alienHelper.iterator());

        while(contentValid && !alienIterStack.isEmpty())
        {
            //go one level up if no more nodes are available for
            //this subtree of subtree
            if(!alienIterStack.get(0).hasNext())
            {
                alienIterStack.remove(0);
                internalIterStack.remove(0);
            }

            //get next node to check of the current subtree of subtree
            Tree<Object> alien = alienIterStack.get(0).next();

            //search for a node with equal content to alien
            Collection<Tree<T>> c = internalIterStack.get(0);
            Optional<Tree<T>> opt = c.stream().filter(t -> t.content.equals(alien.content)).findAny();

            contentValid = opt.isPresent();

            if(!alien.children.isEmpty() && contentValid)
            {
                alienIterStack.add(0 , alien.children.iterator());
                internalIterStack.add(0 , opt.get().children);
            }
        }

        return contentValid;
    }

    //------------------------------------------------------------
    //dove.util
    //------------------------------------------------------------

    /**
     * evaluates the index of an element in a
     * collection returns -1, if the element is no element of
     * the collection
     *
     * @param collection the collection to search in
     * @param t the value to be searched
     * @param <T> the generic type of the collection and the element
     * @return index of the element in the collection of -1 if t is no element
     *      of collection
     */
    private static<T> int indexOf(Collection<T> collection , T t)
    {
        int i = 0;

        for(T val : collection)
        {
            if(val.equals(t))
                return i;

            i++;
        }

        return -1;
    }

    ///////////////////////////////////////////////////////////////
    // Helperclasses
    ///////////////////////////////////////////////////////////////

    /**
     * this class provides an iterator
     * to iterate over the nodes of this tree inorder
     */
    protected class TreeIter
        implements Iterator<Tree<T>>
    {
        /**
         * this list provides the current position in the tree
         */
        private ArrayList<Iterator<Tree<T>>> internalIterStack;

        /**
         * the current node in the tree
         */
        private Tree<T> currentNode;

        /**
         * the root of the tree that is iterated
         */
        private Tree<T> root;

        /**
         * creates a new iterator over this tree starting
         * from root
         *
         * @param root the first node of the iterator
         */
        public TreeIter(Tree<T> root)
        {
            currentNode = root;

            internalIterStack = new ArrayList<>();

            ArrayList<Tree<T>> temp = new ArrayList<>();
            temp.add(root);

            internalIterStack.add(temp.iterator());

            this.root = root;
        }

        @Override
        public boolean hasNext() {
            return (!internalIterStack.isEmpty());
        }

        /**
         * uses internalIterStack to search for the next
         * element in the tree
         *
         * @throws NoSuchElementException if the tree has been fully iterated
         * @return the next node inorder
         */
        @Override
        public Tree<T> next() {
            if (currentNode != null && !currentNode.children.isEmpty())
                internalIterStack.add(0, currentNode.children.iterator());

            while (!internalIterStack.isEmpty() &&
                    !internalIterStack.get(0).hasNext()) {
                internalIterStack.remove(0);
            }

            if (internalIterStack.isEmpty())
                throw new NoSuchElementException();
            else {
                Tree<T> next = internalIterStack.get(0).next();

                currentNode = next;

                return next;
            }
        }

        /**
         * removes the currentNode
         * from the tree
         *
         * this node and all subnodes will be ignored by the iterator
         *
         * @throws IllegalStateException if the currentNode has already been remove
         *      or is the root of the tree
         */
        @Override
        public void remove()
            throws IllegalStateException
        {
            if(currentNode == null)
                throw new IllegalStateException("this node has already been removed from the tree");

            if(currentNode.equals(root))
                throw new IllegalStateException("This node is the root and thus cannot be removed");

            currentNode.getParent().removeSubtree(currentNode);

            currentNode = null;
        }
    }
}