package dove.util.struct.tree;

public class TreeBuildException
    extends Exception
{
    public TreeBuildException(String msg)
    {
        super(msg);
    }
}