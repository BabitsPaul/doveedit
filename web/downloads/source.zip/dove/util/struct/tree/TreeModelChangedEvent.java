package dove.util.struct.tree;

import java.util.EventObject;

public class TreeModelChangedEvent
    extends EventObject
{
    enum TYPE
    {
        ADD,
        REMOVE
    }

    private TYPE type;

    public TreeModelChangedEvent(Tree source , TYPE type)
    {
        super(source);

        this.type = type;
    }

    @Override
    public Tree getSource()
    {
        return (Tree) source;
    }

    public TYPE getType()
    {
        return type;
    }
}
