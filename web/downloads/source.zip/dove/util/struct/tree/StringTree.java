package dove.util.struct.tree;

import java.util.ArrayList;
import java.util.Optional;

public class StringTree<T>
    extends Tree<T>
{
    protected String name;

    public StringTree()
    {
        this("" , null);
    }

    protected StringTree(String name , T t)
    {
        super(t);

        children = new ArrayList<>();

        this.name = name;
    }

    public void insert(String name , T t)
        throws TreeBuildException
    {
        add("." + name , t);
    }

    /**
     * parses a path from name by the following rule:
     * every level is separated by a dot,
     * completes the path and inserts t at the
     * end
     *
     * @param name the path where the value is inserted
     * @param t the value to insert
     * @throws TreeBuildException
     */
    private void add(String name , T t)
            throws TreeBuildException
    {
        int thisIndex = name.indexOf(this.name);
        if(thisIndex == -1)
        {
            throw new TreeBuildException("inserting failed: @path: " + name + "@node: " + this.name);
        }

        int nextNodeStart = thisIndex + this.name.length() + 1;
        int nextNodeEnd = name.indexOf('.', nextNodeStart + 1);

        String nextName;
        StringTree<T> next;

        if(nextNodeEnd == -1){
            //next Node is the last node
            nextName = name.substring(nextNodeStart);
        }else{
            nextName = name.substring(nextNodeStart , nextNodeEnd);
        }

        Optional<Tree<T>> opt = children.stream().
                            filter((Tree<T> node) -> (((StringTree) node).name.equals(nextName))).findAny();

        if(!opt.isPresent())
        {
            //the node with the fullName doesn't exist yet
            next = (nextNodeEnd == -1 ? emptyInsert(nextName , t) : emptyInsert(nextName , null));

            children.add(next);
        }else{
            next = (StringTree<T>) opt.get();
        }

        if(nextNodeEnd != -1)next.add(name , t);
    }

    protected StringTree emptyInsert(String name , T t)
    {
        return new StringTree(name , t);
    }

    public String getName(){return name;}

    //------------------------------------------
    //toString
    //------------------------------------------
    @Override
    protected String getStringRep(){return name;}
}