package dove.util.struct.stringmap;

import dove.util.struct.tree.Tree;
import dove.util.struct.tree.TreeBuildException;

import java.util.Arrays;
import java.util.Set;
import java.util.TreeSet;

public class StringMap<Val>
    extends Tree<Character>
{
    private Val val;

    public StringMap()
    {
        super('\u0000');
    }

    private StringMap(char c, Val v)
    {
        super(c);

        val = v;
    }

    public void put(String key , Val val)
    {
        char[] char_array = key.toCharArray();
        Character[] char_obj = new Character[char_array.length];
        for(int i = 0 ; i < char_array.length ; i++)
            char_obj[i] = char_array[i];

        completePath(char_obj);
        try {
            insertAtPathEnd(Arrays.copyOfRange(char_obj, 0, char_obj.length - 2),
                    new StringMap<Val>(char_obj[char_obj.length - 1], val));
        }catch (TreeBuildException ignored){
            //never thrown, since no structural rules ares broken
        }
    }

    public void remove(String key)
    {
        put(key , null);
    }

    public void removeVal(Val v)
    {
        StringMap<Val> search = searchNodeFor(v);

        if(search == null)
            throw new NullPointerException("this values is not contained in this map");

        search.getParent().remove(search.getContent());
    }

    public Val getVal(){return val;}

    /**
     * creates a keySet for this map
     * null-values are referred to as empty/no valid key
     *
     * @return a string-set containing all keys used in this map
     */
    public Set<String> keySet()
    {
        class KeySetGoMgr
            extends GoThroughManager<Tree<Character>>
        {
            /**
             * the resulting set of keys
             */
            public Set<String> keys = new TreeSet<>();

            /**
             * an internal levelcounter - this value is used to
             * determine the new key if the algorithm goes one level
             * deeper/higher
             */
            private int internalLevelCounter = 0;

            /**
             * the key up to the parent of this node
             */
            private String currentKeyStub = "";

            /**
             * the character of the current node
             */
            private char currentNodeKey;

            /**
             * if the value saved in this node is not null
             * (null values are considered as not set and therefor ignored)
             * the key of this node will be saved in the keySet
             *
             * @param t the node that is inspected
             */
            @Override
            public void accept(Tree<Character> t) {
                currentNodeKey = t.getContent();

                if(((StringMap<Val>) t).val != null)
                {
                    keys.add(currentKeyStub + currentNodeKey);
                }
            }

            /**
             * applies hte levelchange to currentKeyStub
             *
             * @param integer the level, the algorithm currently is running through
             */
            @Override
            public void levelChanged(Integer integer) {
                if(integer > internalLevelCounter)
                    currentKeyStub += currentNodeKey;
                else
                    currentKeyStub.substring(0 , integer);

                internalLevelCounter = integer;
            }
        }

        KeySetGoMgr keySet = new KeySetGoMgr();

        goThroughTree(getRoot() , keySet);

        return keySet.keys;
    }

    private StringMap<Val> searchNodeFor(Val v)
    {
        class SearchMgr
            extends GoThroughManager<Tree<Character>>{
            public StringMap<Val> found = null;

            @Override
            public void accept(Tree<Character> characterTree) {
                if(((StringMap<Val>) characterTree).val.equals(v))
                    found = (StringMap<Val>) characterTree;
            }
        };

        SearchMgr mgr = new SearchMgr();
        goThroughTree(this , mgr);

        return mgr.found;
    }
}