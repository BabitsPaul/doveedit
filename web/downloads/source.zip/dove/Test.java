package dove;

import dove.util.struct.tree.TreeMap;
import dove.util.ui.select.SearchComboBox;

import javax.swing.*;
import java.awt.*;

public class Test {
    public static void main(String[] args)
    {
        new Test();

        JFrame frame = new JFrame("test");
        frame.setLayout(new FlowLayout());
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        TreeMap<Character , String> valMap = new TreeMap<>();
        valMap.put(new Character[]{'h' , 'e' , 'l' , 'l' , 'o'} , "asdf");
        valMap.put(new Character[]{'a' , 'a' , 'a'} , "hello");
        valMap.put(new Character[]{'b' , 'c' , 'd'} , "qwert");

        SearchComboBox scb = new SearchComboBox(valMap);
        scb.addSelectionListener(e -> {
            System.out.println(e.getSelected());
        });
        frame.add(scb);

        frame.setSize(500, 500);
        frame.setVisible(true);
    }
}
