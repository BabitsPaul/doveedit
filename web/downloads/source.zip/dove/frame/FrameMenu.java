package dove.frame;

import dove.Setup;
import dove.document.DocumentContext;
import dove.frame.menubar.MenubarComponent;
import dove.util.struct.tree.StringTree;
import dove.util.struct.tree.TreeBuildException;

import javax.swing.*;

public class FrameMenu
    extends MenubarComponent
{
    private DocumentContext doc;

    public FrameMenu(DocumentContext doc)
    {
        super(doc);

        this.doc = doc;
    }

    @Override
    protected StringTree<JMenuItem> getStructure() {
        //TODO
        StringTree<JMenuItem> result = new StringTree<>();
        try {
            result.insert("Dove", null);

            JMenuItem config = new JMenuItem("Configuration");
            config.addActionListener(e -> doc.configEdit.show());

            JMenuItem exit = new JMenuItem("Exit");
            exit.addActionListener(e -> {
                Setup.tearDown(doc);
            });
            result.insert("Dove.Exit" , exit);
        }catch (TreeBuildException e){}
        return result;
    }
}