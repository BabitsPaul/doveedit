package dove.frame.menubar;

import dove.api.FrameApi;
import dove.document.DocumentContext;
import dove.util.struct.tree.StringTree;
import dove.util.struct.tree.Tree;
import dove.util.struct.tree.TreeBuildException;

import javax.swing.*;
import java.util.ArrayList;
import java.util.Iterator;

public class MenuBar
{
    private StringTree<JMenuItem> content;

    private JMenuBar bar;

    private FrameApi frame;

    public MenuBar(DocumentContext doc , StringTree<JMenuItem> struct)
    {
        frame = doc.frame;

        content = struct;

        bar = doc.frame.getJMenubar();

        reparse();
    }

    public JMenuBar getMenubar()
    {
        return bar;
    }

    public void add(String path , JMenuItem item)
    {
        try {
            content.insert(path, item);
        }catch (TreeBuildException e)
        {
            throw new IllegalArgumentException(e.getMessage());
        }

        reparse();
    }

    public void addAll(StringTree<JMenuItem> items)
    {
        try {
            content.add(items);
        } catch (TreeBuildException e) {
            throw new IllegalArgumentException(e.getMessage());
        }

        reparse();
    }

    private void reparse()
    {
        //TODO not correctly displayed
        frame.update(() -> {
            bar.removeAll();

            content.getChildren().forEach(c -> {
                JMenuItem barMenu;
                if(c.getContent() == null)
                    barMenu = new JMenu(((StringTree) c).getName());
                else
                    barMenu = c.getContent();
                bar.add(barMenu);

                if (!c.getChildren().isEmpty()) {
                    ArrayList<Iterator<Tree<JMenuItem>>> creatorStack = new ArrayList<>();
                    ArrayList<JMenuItem> itemStack = new ArrayList<>();

                    creatorStack.add(c.getChildren().iterator());
                    itemStack.add(barMenu);

                    while (!creatorStack.isEmpty()) {
                        Iterator<Tree<JMenuItem>> iter = creatorStack.get(0);

                        if (iter.hasNext()) {
                            //there are still items left on this treelevel
                            //and in this subtree

                            //insert newly created item in
                            //the menubar
                            Tree<JMenuItem> item = iter.next();
                            JMenuItem temp;
                            if (item.getContent() == null) {
                                String name = ((StringTree) item).getName();
                                temp = new JMenu(name);
                            } else {
                                temp = item.getContent();
                            }
                            itemStack.get(0).add(temp);

                            //check whether to go one step deeper
                            //insert iterator for next level and
                            //current item (root of new subtree for next menulevel)
                            if (!item.getChildren().isEmpty()) {
                                creatorStack.add(0, item.getChildren().iterator());
                                itemStack.add(0, temp);
                            }
                        } else {
                            //no items left on this level
                            //go one level down (remove current stack items)
                            itemStack.remove(0);
                            creatorStack.remove(0);
                        }
                    }
                }
            });
        });
    }
}