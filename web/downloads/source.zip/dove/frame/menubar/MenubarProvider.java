package dove.frame.menubar;

import javax.swing.*;

public interface MenubarProvider {
    public void updateMenuBar(JMenuBar menuBar);
}
