package dove.frame.menubar;

import dove.document.DocumentContext;
import dove.util.struct.tree.StringTree;

import javax.swing.*;

public abstract class MenubarComponent{
    public MenubarComponent(DocumentContext doc)
    {
        doc.menuTodo.register(this);
    }

    protected abstract StringTree<JMenuItem> getStructure();
}