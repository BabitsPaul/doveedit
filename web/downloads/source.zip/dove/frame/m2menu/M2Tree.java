package dove.frame.m2menu;

import dove.util.struct.tree.Tree;

import java.util.ArrayList;

public class M2Tree
    extends Tree<String>
{
    public M2Tree()
    {
        super("");

        children = new ArrayList<>();
    }
}
