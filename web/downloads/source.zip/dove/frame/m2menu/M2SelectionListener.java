package dove.frame.m2menu;

public interface M2SelectionListener
{
    public void optionSelected(String[] optionPath);
}
